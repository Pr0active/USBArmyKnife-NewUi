import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Files from './pages/Files'
import Scripts from './pages/Scripts'
import Marauder from './pages/Marauder'
import Display from './pages/Display'
import Keyboard from './pages/Keyboard'
import Agent from './pages/Agent'
import Logs from './pages/Logs'
import Docs from './pages/Docs'
import Settings from './pages/Settings'
import { ToastContainer } from './utils/toast'

function App() {
  return (
    <BrowserRouter basename="/USBArmyKnife-web">
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/files" element={<Files />} />
          <Route path="/scripts" element={<Scripts />} />
          <Route path="/marauder" element={<Marauder />} />
          <Route path="/display" element={<Display />} />
          <Route path="/keyboard" element={<Keyboard />} />
          <Route path="/agent" element={<Agent />} />
          <Route path="/logs" element={<Logs />} />
          <Route path="/docs" element={<Docs />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </Layout>
      <ToastContainer />
    </BrowserRouter>
  )
}

export default App
